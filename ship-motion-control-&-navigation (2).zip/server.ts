import express from 'express';
import { createServer as createViteServer } from 'vite';
import RBush from 'rbush';
import fs from 'fs';

const BASE_LAT = 37.8267;
const BASE_LNG = -122.4230;
const R = 6378137; // Earth radius in meters

function toLocal(lat: number, lng: number) {
  const x = lng * R * Math.PI / 180;
  const y = R * Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360));
  const refX = BASE_LNG * R * Math.PI / 180;
  const refY = R * Math.log(Math.tan(Math.PI / 4 + BASE_LAT * Math.PI / 360));
  return { x: x - refX, y: y - refY };
}

function toGeo(x: number, y: number) {
  const refX = BASE_LNG * R * Math.PI / 180;
  const refY = R * Math.log(Math.tan(Math.PI / 4 + BASE_LAT * Math.PI / 360));
  const absX = x + refX;
  const absY = y + refY;
  const lng = absX / (R * Math.PI / 180);
  const lat = (2 * Math.atan(Math.exp(absY / R)) - Math.PI / 2) * 180 / Math.PI;
  return { lat, lng };
}


const segmentTree = new RBush();
const polygonTree = new RBush();

function initGlobalLand() {
  let segments: any[] = [];
  let polygons: any[] = [];
  
  const localPolygons = [
    [{lat: 37.8100, lng: -122.4800}, {lat: 37.8050, lng: -122.4500}, {lat: 37.8080, lng: -122.4300}, {lat: 37.8000, lng: -122.4000}, {lat: 37.7800, lng: -122.3800}, {lat: 37.7500, lng: -122.3800}, {lat: 37.7000, lng: -122.3800}, {lat: 37.6500, lng: -122.3800}, {lat: 37.6000, lng: -122.3500}, {lat: 37.5500, lng: -122.3000}, {lat: 37.5500, lng: -122.5500}, {lat: 37.7500, lng: -122.5500}],
    [{lat: 37.9500, lng: -122.4000}, {lat: 37.9000, lng: -122.3500}, {lat: 37.8800, lng: -122.3200}, {lat: 37.8300, lng: -122.3000}, {lat: 37.8000, lng: -122.3200}, {lat: 37.7500, lng: -122.2500}, {lat: 37.7000, lng: -122.2000}, {lat: 37.6500, lng: -122.1500}, {lat: 37.6500, lng: -122.0000}, {lat: 37.9500, lng: -122.0000}],
    [{lat: 37.8200, lng: -122.4800}, {lat: 37.8300, lng: -122.4600}, {lat: 37.8500, lng: -122.4500}, {lat: 37.8600, lng: -122.4200}, {lat: 37.8800, lng: -122.4200}, {lat: 37.9500, lng: -122.4500}, {lat: 37.9500, lng: -122.6000}, {lat: 37.8200, lng: -122.6000}],
    [{lat: 37.8280, lng: -122.4240}, {lat: 37.8280, lng: -122.4220}, {lat: 37.8250, lng: -122.4210}, {lat: 37.8250, lng: -122.4240}],
    [{lat: 37.8300, lng: -122.3750}, {lat: 37.8300, lng: -122.3650}, {lat: 37.8150, lng: -122.3600}, {lat: 37.8050, lng: -122.3650}, {lat: 37.8050, lng: -122.3700}, {lat: 37.8150, lng: -122.3750}],
    [{lat: 37.8650, lng: -122.4400}, {lat: 37.8650, lng: -122.4200}, {lat: 37.8550, lng: -122.4200}, {lat: 37.8550, lng: -122.4400}]
  ];

  for (const poly of localPolygons) {
    let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity;
    const coords = poly.map(p => {
      if (p.lng < minLng) minLng = p.lng;
      if (p.lng > maxLng) maxLng = p.lng;
      if (p.lat < minLat) minLat = p.lat;
      if (p.lat > maxLat) maxLat = p.lat;
      return [p.lng, p.lat];
    });
    polygons.push({ minX: minLng, minY: minLat, maxX: maxLng, maxY: maxLat, coords: [coords] });

    for (let i = 0; i < poly.length; i++) {
      const p1 = toLocal(poly[i].lat, poly[i].lng);
      const p2 = toLocal(poly[(i+1)%poly.length].lat, poly[(i+1)%poly.length].lng);
      segments.push({
        minX: Math.min(p1.x, p2.x), minY: Math.min(p1.y, p2.y),
        maxX: Math.max(p1.x, p2.x), maxY: Math.max(p1.y, p2.y),
        p1, p2
      });
    }
  }

  try {
    const geojson = JSON.parse(fs.readFileSync('land_10m.geojson', 'utf8'));
    function processPolygon(coords: any[]) {
      let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity;
      for (const ring of coords) {
        for (const p of ring) {
          if (p[0] < minLng) minLng = p[0];
          if (p[0] > maxLng) maxLng = p[0];
          if (p[1] < minLat) minLat = p[1];
          if (p[1] > maxLat) maxLat = p[1];
        }
        for (let i = 0; i < ring.length - 1; i++) {
          const p1 = toLocal(ring[i][1], ring[i][0]);
          const p2 = toLocal(ring[i+1][1], ring[i+1][0]);
          segments.push({
            minX: Math.min(p1.x, p2.x), minY: Math.min(p1.y, p2.y),
            maxX: Math.max(p1.x, p2.x), maxY: Math.max(p1.y, p2.y),
            p1, p2
          });
        }
      }
      polygons.push({ minX: minLng, minY: minLat, maxX: maxLng, maxY: maxLat, coords });
    }

    for (const feature of geojson.features) {
      if (feature.geometry.type === 'Polygon') {
        processPolygon(feature.geometry.coordinates);
      } else if (feature.geometry.type === 'MultiPolygon') {
        for (const poly of feature.geometry.coordinates) {
          processPolygon(poly);
        }
      }
    }
  } catch (e) {
    console.error('Could not load land_10m.geojson', e);
  }

  segmentTree.load(segments);
  polygonTree.load(polygons);
  console.log('Loaded global land data. Segments:', segments.length, 'Polygons:', polygons.length);
}

initGlobalLand();

function pointToSegmentDistance(px: number, py: number, x1: number, y1: number, x2: number, y2: number) {
  const l2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
  if (l2 === 0) return Math.hypot(px - x1, py - y1);
  let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (x1 + t * (x2 - x1)), py - (y1 + t * (y2 - y1)));
}

function isPointInGeoJSONPolygon(px: number, py: number, coords: any[]) {
  let inside = false;
  // coords is an array of rings. The first is the exterior ring, others are holes.
  for (let i = 0; i < coords.length; i++) {
    const ring = coords[i];
    let ringInside = false;
    for (let j = 0, k = ring.length - 1; j < ring.length; k = j++) {
      const p1 = toLocal(ring[j][1], ring[j][0]);
      const p2 = toLocal(ring[k][1], ring[k][0]);
      const intersect = ((p1.y > py) !== (p2.y > py)) &&
          (px < (p2.x - p1.x) * (py - p1.y) / (p2.y - p1.y) + p1.x);
      if (intersect) ringInside = !ringInside;
    }
    if (i === 0) {
      inside = ringInside;
    } else if (ringInside) {
      // If inside a hole, then it's outside the polygon
      inside = false;
    }
  }
  return inside;
}

function getDistanceToPolygons(px: number, py: number, _ignored?: any[]) {
  // First check if point is inside any polygon
  const geo = toGeo(px, py);
  const polys = polygonTree.search({
    minX: geo.lng, minY: geo.lat,
    maxX: geo.lng, maxY: geo.lat
  });
  for (const poly of polys as any[]) {
    if (isPointInGeoJSONPolygon(px, py, poly.coords)) {
      return 0; // Inside land
    }
  }

  const searchRadius = 2000;
  const results = segmentTree.search({
    minX: px - searchRadius, minY: py - searchRadius,
    maxX: px + searchRadius, maxY: py + searchRadius
  });
  
  if (results.length === 0) return searchRadius;
  
  let minDist = Infinity;
  for (const seg of results as any[]) {
    const dist = pointToSegmentDistance(px, py, seg.p1.x, seg.p1.y, seg.p2.x, seg.p2.y);
    if (dist < minDist) minDist = dist;
  }
  return minDist;
}

const landPolygons: any[] = []; // Dummy for compatibility


const app = express();
app.use(express.json());

// --- Simulation Logic ---
class ShipSimulation {
  K = 0.5;
  T1 = 20.0;
  T2 = 2.0;
  T3 = 5.0;
  TE = 0.5;
  U = 5.0;

  x = -4000;
  y = -500;
  psi = 0;
  r = 0;
  r_dot = 0;
  delta = 0;
  delta_c = 0;

  mode: 'auto' | 'manual' = 'auto';
  manual_delta_c = 0;
  collision_warning = false;
  ddpg_active = false;
  perception_radius = 800;

  waypoints: {x: number, y: number}[] = [];
  currentWaypointIndex = 0;
  history: {x: number, y: number}[] = [];

  Kp = 5.0;
  Kd = 15.0;

  obstacles = landPolygons;

  update(dt: number) {
    // Rudder dynamics
    const delta_dot = (this.delta_c - this.delta) / this.TE;
    this.delta += delta_dot * dt;

    // Nomoto 2nd order
    const r_ddot = (this.K * (this.delta + this.T3 * delta_dot) - (this.T1 + this.T2) * this.r_dot - this.r) / (this.T1 * this.T2);

    this.r_dot += r_ddot * dt;
    this.r += this.r_dot * dt;
    this.psi += this.r * dt;

    // Normalize psi
    while (this.psi > Math.PI) this.psi -= 2 * Math.PI;
    while (this.psi < -Math.PI) this.psi += 2 * Math.PI;

    this.x += this.U * Math.cos(this.psi) * dt;
    this.y += this.U * Math.sin(this.psi) * dt;

    // Save history (throttle to avoid huge arrays)
    if (Math.random() < 0.1) {
      this.history.push({ x: this.x, y: this.y });
      if (this.history.length > 500) this.history.shift();
    }

    // Collision detection
    this.collision_warning = false;
    this.ddpg_active = false;
    const distToLand = getDistanceToPolygons(this.x, this.y, this.obstacles);
    if (distToLand < 100) { // 100m warning
      this.collision_warning = true;
    }

    if (this.mode === 'auto') {
      if (this.currentWaypointIndex < this.waypoints.length) {
        const target = this.waypoints[this.currentWaypointIndex];
        const distToTarget = Math.hypot(target.x - this.x, target.y - this.y);

        if (distToTarget < 50) {
          this.currentWaypointIndex++;
        } else if (distToLand < this.perception_radius) {
          // DDPG Local Planner (Simulated via DWA / Potential Field)
          this.ddpg_active = true;
          
          let best_delta_c = 0;
          let max_reward = -Infinity;
          
          // Action space: -35 to 35 degrees rudder
          for (let a = -35; a <= 35; a += 5) {
            const test_delta = a * Math.PI / 180;
            
            // Predict future state (simple kinematic model for 10 seconds)
            const future_psi = this.psi + this.r * 10 + (this.K * test_delta) * 10;
            const future_x = this.x + this.U * Math.cos(future_psi) * 10;
            const future_y = this.y + this.U * Math.sin(future_psi) * 10;
            
            const future_dist_land = getDistanceToPolygons(future_x, future_y, this.obstacles);
            const future_dist_target = Math.hypot(target.x - future_x, target.y - future_y);
            
            // Reward Function (DDPG Critic Network Simulation):
            // + Progress to target
            // - Penalty for being close to land (exponential)
            // - Penalty for large rudder angles (fuel efficiency)
            let reward = -future_dist_target;
            
            if (future_dist_land < 150) {
               reward -= 100000 * Math.exp(-future_dist_land / 50); // Severe penalty (Collision)
            } else if (future_dist_land < 400) {
               reward -= 5000 * Math.exp(-future_dist_land / 100); // Soft penalty (Keep distance)
            }
            
            reward -= Math.abs(a) * 10; // Fuel efficiency penalty
            
            if (reward > max_reward) {
              max_reward = reward;
              best_delta_c = test_delta;
            }
          }
          
          // Apply DDPG action with smoothing
          this.delta_c = this.delta_c * 0.8 + best_delta_c * 0.2;
        } else {
          // Open water: use standard LOS guidance
          this.navigate();
        }
      }
    } else {
      this.delta_c = this.manual_delta_c;
    }
  }

  navigate() {
    if (this.currentWaypointIndex < this.waypoints.length) {
      const target = this.waypoints[this.currentWaypointIndex];
      const dx = target.x - this.x;
      const dy = target.y - this.y;
      const dist = Math.hypot(dx, dy);

      if (dist < 50) {
        this.currentWaypointIndex++;
      } else {
        // Line-of-Sight (LOS) Guidance Law
        const prevTarget = this.currentWaypointIndex > 0 
          ? this.waypoints[this.currentWaypointIndex - 1] 
          : { x: this.history.length > 0 ? this.history[this.history.length-1].x : this.x, 
              y: this.history.length > 0 ? this.history[this.history.length-1].y : this.y };

        const path_dx = target.x - prevTarget.x;
        const path_dy = target.y - prevTarget.y;
        const path_len = Math.hypot(path_dx, path_dy);

        let psi_d = 0;

        if (path_len < 1) {
          psi_d = Math.atan2(dy, dx);
        } else {
          const alpha_k = Math.atan2(path_dy, path_dx);
          // Cross-track error
          const ex = this.x - prevTarget.x;
          const ey = this.y - prevTarget.y;
          const ye = -ex * Math.sin(alpha_k) + ey * Math.cos(alpha_k);

          const Delta = 150.0; // Lookahead distance
          psi_d = alpha_k + Math.atan(-ye / Delta);
        }

        let error = psi_d - this.psi;
        while (error > Math.PI) error -= 2 * Math.PI;
        while (error < -Math.PI) error += 2 * Math.PI;

        this.delta_c = this.Kp * error - this.Kd * this.r;
        const max_delta = 35 * Math.PI / 180;
        if (this.delta_c > max_delta) this.delta_c = max_delta;
        if (this.delta_c < -max_delta) this.delta_c = -max_delta;
      }
    } else {
      this.delta_c = 0;
    }
  }

  setTarget(endX: number, endY: number) {
    this.waypoints = aStar(this.x, this.y, endX, endY, this.obstacles);
    this.currentWaypointIndex = 0;
  }
}

function heuristic(a: any, b: any) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function getNeighbors(node: any, obstacles: any[]) {
  const neighbors = [];
  const step = 100;
  const dirs = [
    [0, step], [0, -step], [step, 0], [-step, 0],
    [step, step], [step, -step], [-step, step], [-step, -step]
  ];
  for (const dir of dirs) {
    const nx = node.x + dir[0];
    const ny = node.y + dir[1];
    const dist = getDistanceToPolygons(nx, ny, obstacles);
    if (dist > 150) { // Keep at least 150m away to avoid 100m collision warning
      neighbors.push({ x: nx, y: ny });
    }
  }
  return neighbors;
}

function lineOfSight(p1: any, p2: any, obstacles: any[]) {
  const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
  const steps = Math.max(1, Math.ceil(dist / 50));
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = p1.x + t * (p2.x - p1.x);
    const y = p1.y + t * (p2.y - p1.y);
    if (getDistanceToPolygons(x, y, obstacles) < 150) return false;
  }
  return true;
}

class MinHeap {
  heap: any[] = [];
  push(node: any) {
    this.heap.push(node);
    this.bubbleUp(this.heap.length - 1);
  }
  pop() {
    if (this.heap.length === 0) return null;
    if (this.heap.length === 1) return this.heap.pop();
    const top = this.heap[0];
    this.heap[0] = this.heap.pop();
    this.sinkDown(0);
    return top;
  }
  bubbleUp(index: number) {
    const node = this.heap[index];
    while (index > 0) {
      const parentIndex = Math.floor((index - 1) / 2);
      const parent = this.heap[parentIndex];
      if (node.f >= parent.f) break;
      this.heap[parentIndex] = node;
      this.heap[index] = parent;
      index = parentIndex;
    }
  }
  sinkDown(index: number) {
    const length = this.heap.length;
    const node = this.heap[index];
    while (true) {
      let leftChildIndex = 2 * index + 1;
      let rightChildIndex = 2 * index + 2;
      let leftChild, rightChild;
      let swap = null;

      if (leftChildIndex < length) {
        leftChild = this.heap[leftChildIndex];
        if (leftChild.f < node.f) swap = leftChildIndex;
      }
      if (rightChildIndex < length) {
        rightChild = this.heap[rightChildIndex];
        if ((swap === null && rightChild.f < node.f) || (swap !== null && rightChild.f < leftChild.f)) {
          swap = rightChildIndex;
        }
      }
      if (swap === null) break;
      this.heap[index] = this.heap[swap];
      this.heap[swap] = node;
      index = swap;
    }
  }
  isEmpty() {
    return this.heap.length === 0;
  }
}

function smoothPath(path: any[], obstacles: any[]) {
  if (path.length <= 2) return path;
  
  // 1. Greedy line-of-sight smoothing
  const greedy = [path[0]];
  let current = path[0];
  let i = 1;
  while (i < path.length - 1) {
    if (!lineOfSight(current, path[i + 1], obstacles)) {
      greedy.push(path[i]);
      current = path[i];
    }
    i++;
  }
  greedy.push(path[path.length - 1]);

  // 2. Safe Corner Cutting (Chaikin's algorithm variant) to save fuel by smoothing sharp turns
  let smoothed = greedy;
  for (let iter = 0; iter < 2; iter++) {
    if (smoothed.length <= 2) break;
    const nextSmoothed = [smoothed[0]];
    for (let j = 1; j < smoothed.length - 1; j++) {
      const prev = smoothed[j - 1];
      const curr = smoothed[j];
      const next = smoothed[j + 1];
      
      // Calculate points at 25% and 75% along the segments
      const q = { x: 0.25 * prev.x + 0.75 * curr.x, y: 0.25 * prev.y + 0.75 * curr.y };
      const r = { x: 0.75 * curr.x + 0.25 * next.x, y: 0.75 * curr.y + 0.25 * next.y };
      
      // Only cut the corner if the new shortcut is safe from obstacles
      if (lineOfSight(q, r, obstacles)) {
        nextSmoothed.push(q);
        nextSmoothed.push(r);
      } else {
        nextSmoothed.push(curr);
      }
    }
    nextSmoothed.push(smoothed[smoothed.length - 1]);
    smoothed = nextSmoothed;
  }
  
  return smoothed;
}

function aStar(startX: number, startY: number, endX: number, endY: number, obstacles: any[]) {
  const step = 100;
  const sx = Math.round(startX / step) * step;
  const sy = Math.round(startY / step) * step;
  const ex = Math.round(endX / step) * step;
  const ey = Math.round(endY / step) * step;

  const openSet = new MinHeap();
  openSet.push({ x: sx, y: sy, g: 0, f: 0, parent: null as any });
  const closedSet = new Set();
  const openMap = new Map();
  openMap.set(`${sx},${sy}`, 0);
  
  let iterations = 0;
  let closestNode = openSet.heap[0];
  let minH = heuristic({x: sx, y: sy}, {x: ex, y: ey});

  while (!openSet.isEmpty() && iterations < 100000) {
    iterations++;
    
    const current = openSet.pop();
    const key = `${current.x},${current.y}`;
    
    if (closedSet.has(key)) continue;
    closedSet.add(key);

    const h = heuristic(current, { x: ex, y: ey });
    if (h < minH) {
      minH = h;
      closestNode = current;
    }

    if (Math.hypot(current.x - ex, current.y - ey) < step * 1.5) {
      const path = [];
      let curr = current;
      while (curr) {
        path.unshift({ x: curr.x, y: curr.y });
        curr = curr.parent;
      }
      path.push({ x: endX, y: endY });
      return smoothPath(path, obstacles);
    }

    const neighbors = getNeighbors(current, obstacles);
    for (const n of neighbors) {
      const nKey = `${n.x},${n.y}`;
      if (closedSet.has(nKey)) continue;

      let parent = current;
      let g = current.g + Math.hypot(n.x - current.x, n.y - current.y);

      // Proactive Obstacle Avoidance: Add penalty for being close to land
      const distToLand = getDistanceToPolygons(n.x, n.y, obstacles);
      if (distToLand < 400) {
        g += (400 - distToLand) * 1.5; // Soft penalty to keep ship in deep water
      }

      // COLREGs Rule 9: Keep to the starboard (right) side of the channel
      const cross = (ex - sx) * (n.y - sy) - (ey - sy) * (n.x - sx);
      if (cross > 0) {
         g += 20; // Soft penalty for being on the port (left) side of the direct route
      }

      // Theta* Line-of-Sight optimization
      if (current.parent && lineOfSight(current.parent, n, obstacles)) {
        const g_los = current.parent.g + Math.hypot(n.x - current.parent.x, n.y - current.parent.y);
        // Apply the same penalties to LOS path
        let los_penalty = 0;
        if (distToLand < 400) los_penalty += (400 - distToLand) * 1.5;
        if (cross > 0) los_penalty += 20;
        
        if (g_los + los_penalty < g) {
          parent = current.parent;
          g = g_los + los_penalty;
        }
      }

      const f = g + heuristic(n, { x: ex, y: ey });
      
      const existingG = openMap.get(nKey);
      if (existingG === undefined || g < existingG) {
        openMap.set(nKey, g);
        openSet.push({ x: n.x, y: n.y, g, f, parent });
      }
    }
  }
  
  // If no path found or iterations exceeded, return path to closest valid node
  if (closestNode) {
    const path = [];
    let curr = closestNode;
    while (curr) {
      path.unshift({ x: curr.x, y: curr.y });
      curr = curr.parent;
    }
    return smoothPath(path, obstacles);
  }

  return [{x: endX, y: endY}];
}

const ship = new ShipSimulation();

setInterval(() => {
  ship.update(0.05);
}, 50);

app.get('/api/state', (req, res) => {
  const predicted = [];
  let px = ship.x, py = ship.y, ppsi = ship.psi, pr = ship.r, pr_dot = ship.r_dot, pdelta = ship.delta;
  for(let i=0; i<15; i++) {
    const dt = 1.0;
    const delta_dot = (ship.delta_c - pdelta) / ship.TE;
    pdelta += delta_dot * dt;
    const r_ddot = (ship.K * (pdelta + ship.T3 * delta_dot) - (ship.T1 + ship.T2) * pr_dot - pr) / (ship.T1 * ship.T2);
    pr_dot += r_ddot * dt;
    pr += pr_dot * dt;
    ppsi += pr * dt;
    px += ship.U * Math.cos(ppsi) * dt;
    py += ship.U * Math.sin(ppsi) * dt;
    predicted.push({x: px, y: py});
  }

  res.json({
    x: ship.x,
    y: ship.y,
    psi: ship.psi,
    r: ship.r,
    delta: ship.delta,
    delta_c: ship.delta_c,
    U: ship.U,
    mode: ship.mode,
    collision_warning: ship.collision_warning,
    waypoints: ship.waypoints,
    currentWaypointIndex: ship.currentWaypointIndex,
    history: ship.history,
    ddpg_active: ship.ddpg_active,
    perception_radius: ship.perception_radius,
    predicted: predicted,
    params: {
      K: ship.K,
      T1: ship.T1,
      T2: ship.T2,
      T3: ship.T3,
      Kp: ship.Kp,
      Kd: ship.Kd,
      U: ship.U
    }
  });
});

app.get('/api/land', (req, res) => {
  const { minLng, minLat, maxLng, maxLat } = req.query;
  if (!minLng || !minLat || !maxLng || !maxLat) return res.json({ type: 'FeatureCollection', features: [] });
  
  const results = polygonTree.search({
    minX: Number(minLng), minY: Number(minLat),
    maxX: Number(maxLng), maxY: Number(maxLat)
  });
  
  const features = results.map((poly: any) => ({
    type: 'Feature',
    geometry: {
      type: 'Polygon',
      coordinates: poly.coords
    },
    properties: {}
  }));
  
  res.json({ type: 'FeatureCollection', features });
});

const buoys: any[] = [];

app.get('/api/obstacles', (req, res) => {
  res.json({ polygons: ship.obstacles, buoys });
});

app.post('/api/target', (req, res) => {
  const { x, y } = req.body;
  ship.setTarget(x, y);
  res.json({ success: true });
});

app.post('/api/mode', (req, res) => {
  const { mode } = req.body;
  if (mode === 'auto' || mode === 'manual') {
    ship.mode = mode;
  }
  res.json({ success: true });
});

app.post('/api/manual_control', (req, res) => {
  const { delta_c } = req.body;
  if (typeof delta_c === 'number') {
    ship.manual_delta_c = delta_c;
  }
  res.json({ success: true });
});

app.post('/api/params', (req, res) => {
  const p = req.body;
  if (p.K !== undefined) ship.K = p.K;
  if (p.T1 !== undefined) ship.T1 = p.T1;
  if (p.T2 !== undefined) ship.T2 = p.T2;
  if (p.T3 !== undefined) ship.T3 = p.T3;
  if (p.Kp !== undefined) ship.Kp = p.Kp;
  if (p.Kd !== undefined) ship.Kd = p.Kd;
  if (p.U !== undefined) ship.U = p.U;
  res.json({ success: true });
});

app.post('/api/reset', (req, res) => {
  ship.x = -4000;
  ship.y = -500;
  ship.psi = 0;
  ship.r = 0;
  ship.r_dot = 0;
  ship.delta = 0;
  ship.delta_c = 0;
  ship.waypoints = [];
  ship.currentWaypointIndex = 0;
  ship.history = [];
  res.json({ success: true });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(3000, '0.0.0.0', () => {
    console.log('Server running on port 3000');
  });
}

startServer();
