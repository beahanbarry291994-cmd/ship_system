import express from 'express';
import { createServer as createViteServer } from 'vite';

const BASE_LAT = 37.8267;
const BASE_LNG = -122.4230;
const METERS_PER_DEG_LAT = 111320;
const METERS_PER_DEG_LNG = 111320 * Math.cos(BASE_LAT * Math.PI / 180);

function toLocal(lat: number, lng: number) {
  return {
    x: (lng - BASE_LNG) * METERS_PER_DEG_LNG,
    y: (lat - BASE_LAT) * METERS_PER_DEG_LAT
  };
}

const landPolygons = [
  // Alcatraz
  [{lat: 37.8280, lng: -122.4240}, {lat: 37.8280, lng: -122.4220}, {lat: 37.8250, lng: -122.4210}, {lat: 37.8250, lng: -122.4240}],
  // SF Coast
  [{lat: 37.8100, lng: -122.4800}, {lat: 37.8050, lng: -122.4500}, {lat: 37.8080, lng: -122.4300}, {lat: 37.8000, lng: -122.4000}, {lat: 37.7800, lng: -122.3800}, {lat: 37.7500, lng: -122.3800}, {lat: 37.7500, lng: -122.5000}, {lat: 37.8100, lng: -122.5000}],
  // Marin Coast
  [{lat: 37.8200, lng: -122.4800}, {lat: 37.8300, lng: -122.4600}, {lat: 37.8500, lng: -122.4500}, {lat: 37.8600, lng: -122.4200}, {lat: 37.8800, lng: -122.4200}, {lat: 37.8800, lng: -122.5000}, {lat: 37.8200, lng: -122.5000}],
  // Treasure Island
  [{lat: 37.8300, lng: -122.3750}, {lat: 37.8300, lng: -122.3650}, {lat: 37.8150, lng: -122.3600}, {lat: 37.8050, lng: -122.3650}, {lat: 37.8050, lng: -122.3700}, {lat: 37.8150, lng: -122.3750}],
  // Angel Island
  [{lat: 37.8650, lng: -122.4400}, {lat: 37.8650, lng: -122.4200}, {lat: 37.8550, lng: -122.4200}, {lat: 37.8550, lng: -122.4400}]
].map(poly => poly.map(p => toLocal(p.lat, p.lng)));

function pointToSegmentDistance(px: number, py: number, x1: number, y1: number, x2: number, y2: number) {
  const A = px - x1;
  const B = py - y1;
  const C = x2 - x1;
  const D = y2 - y1;
  const dot = A * C + B * D;
  const len_sq = C * C + D * D;
  let param = -1;
  if (len_sq != 0) param = dot / len_sq;
  let xx, yy;
  if (param < 0) { xx = x1; yy = y1; }
  else if (param > 1) { xx = x2; yy = y2; }
  else { xx = x1 + param * C; yy = y1 + param * D; }
  const dx = px - xx;
  const dy = py - yy;
  return Math.sqrt(dx * dx + dy * dy);
}

function isPointInPolygon(px: number, py: number, polygon: {x: number, y: number}[]) {
  let isInside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x, yi = polygon[i].y;
    const xj = polygon[j].x, yj = polygon[j].y;
    const intersect = ((yi > py) != (yj > py)) && (px < (xj - xi) * (py - yi) / (yj - yi) + xi);
    if (intersect) isInside = !isInside;
  }
  return isInside;
}

function getDistanceToPolygons(px: number, py: number, polygons: {x: number, y: number}[][]) {
  let minDist = Infinity;
  for (const poly of polygons) {
    if (isPointInPolygon(px, py, poly)) return 0;
    for (let i = 0; i < poly.length; i++) {
      const p1 = poly[i];
      const p2 = poly[(i + 1) % poly.length];
      const dist = pointToSegmentDistance(px, py, p1.x, p1.y, p2.x, p2.y);
      if (dist < minDist) minDist = dist;
    }
  }
  return minDist;
}

const app = express();
app.use(express.json());

// --- Simulation Logic ---
class ShipSimulation {
  K = 0.5;
  T1 = 20.0;
  T2 = 2.0;
  T3 = 5.0;
  TE = 0.5;
  U = 5.0;

  x = -4000;
  y = -500;
  psi = 0;
  r = 0;
  r_dot = 0;
  delta = 0;
  delta_c = 0;

  mode: 'auto' | 'manual' = 'auto';
  manual_delta_c = 0;
  collision_warning = false;

  waypoints: {x: number, y: number}[] = [];
  currentWaypointIndex = 0;
  history: {x: number, y: number}[] = [];

  Kp = 5.0;
  Kd = 15.0;

  obstacles = landPolygons;

  update(dt: number) {
    // Rudder dynamics
    const delta_dot = (this.delta_c - this.delta) / this.TE;
    this.delta += delta_dot * dt;

    // Nomoto 2nd order
    const r_ddot = (this.K * (this.delta + this.T3 * delta_dot) - (this.T1 + this.T2) * this.r_dot - this.r) / (this.T1 * this.T2);

    this.r_dot += r_ddot * dt;
    this.r += this.r_dot * dt;
    this.psi += this.r * dt;

    // Normalize psi
    while (this.psi > Math.PI) this.psi -= 2 * Math.PI;
    while (this.psi < -Math.PI) this.psi += 2 * Math.PI;

    this.x += this.U * Math.cos(this.psi) * dt;
    this.y += this.U * Math.sin(this.psi) * dt;

    // Save history (throttle to avoid huge arrays)
    if (Math.random() < 0.1) {
      this.history.push({ x: this.x, y: this.y });
      if (this.history.length > 500) this.history.shift();
    }

    // Collision detection
    this.collision_warning = false;
    const distToLand = getDistanceToPolygons(this.x, this.y, this.obstacles);
    if (distToLand < 100) { // 100m warning
      this.collision_warning = true;
      
      // Simple reactive collision avoidance in auto mode
      if (this.mode === 'auto' && distToLand < 60) {
         const distLeft = getDistanceToPolygons(this.x + Math.cos(this.psi - Math.PI/2)*20, this.y + Math.sin(this.psi - Math.PI/2)*20, this.obstacles);
         const distRight = getDistanceToPolygons(this.x + Math.cos(this.psi + Math.PI/2)*20, this.y + Math.sin(this.psi + Math.PI/2)*20, this.obstacles);
         
         // Steer towards the side with more space
         if (distLeft > distRight) {
           this.delta_c = -35 * Math.PI / 180; // Hard port
         } else {
           this.delta_c = 35 * Math.PI / 180; // Hard starboard
         }
         // Skip normal navigation if avoiding
         return;
      }
    }

    if (this.mode === 'auto') {
      this.navigate();
    } else {
      this.delta_c = this.manual_delta_c;
    }
  }

  navigate() {
    if (this.currentWaypointIndex < this.waypoints.length) {
      const target = this.waypoints[this.currentWaypointIndex];
      const dx = target.x - this.x;
      const dy = target.y - this.y;
      const dist = Math.sqrt(dx*dx + dy*dy);

      if (dist < 30) {
        this.currentWaypointIndex++;
      } else {
        let psi_d = Math.atan2(dy, dx);
        let error = psi_d - this.psi;
        while (error > Math.PI) error -= 2 * Math.PI;
        while (error < -Math.PI) error += 2 * Math.PI;

        this.delta_c = this.Kp * error - this.Kd * this.r;
        const max_delta = 35 * Math.PI / 180;
        if (this.delta_c > max_delta) this.delta_c = max_delta;
        if (this.delta_c < -max_delta) this.delta_c = -max_delta;
      }
    } else {
      this.delta_c = 0;
    }
  }

  setTarget(endX: number, endY: number) {
    this.waypoints = aStar(this.x, this.y, endX, endY, this.obstacles);
    this.currentWaypointIndex = 0;
  }
}

function heuristic(a: any, b: any) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function getNeighbors(node: any, obstacles: any[]) {
  const neighbors = [];
  const step = 100;
  const dirs = [
    [0, step], [0, -step], [step, 0], [-step, 0],
    [step, step], [step, -step], [-step, step], [-step, -step]
  ];
  for (const dir of dirs) {
    const nx = node.x + dir[0];
    const ny = node.y + dir[1];
    if (nx >= -10000 && nx <= 10000 && ny >= -10000 && ny <= 10000) {
      const dist = getDistanceToPolygons(nx, ny, obstacles);
      if (dist > 50) {
        neighbors.push({ x: nx, y: ny });
      }
    }
  }
  return neighbors;
}

function aStar(startX: number, startY: number, endX: number, endY: number, obstacles: any[]) {
  const step = 100;
  const sx = Math.round(startX / step) * step;
  const sy = Math.round(startY / step) * step;
  const ex = Math.round(endX / step) * step;
  const ey = Math.round(endY / step) * step;

  const openSet = [{ x: sx, y: sy, g: 0, f: 0, parent: null as any }];
  const closedSet = new Set();
  let iterations = 0;

  while (openSet.length > 0 && iterations < 2000) {
    iterations++;
    
    // Find node with lowest f score (O(N) instead of O(N log N) sort)
    let minIndex = 0;
    for (let i = 1; i < openSet.length; i++) {
      if (openSet[i].f < openSet[minIndex].f) {
        minIndex = i;
      }
    }
    const current = openSet.splice(minIndex, 1)[0];

    const key = `${current.x},${current.y}`;
    if (closedSet.has(key)) continue;
    closedSet.add(key);

    if (Math.hypot(current.x - ex, current.y - ey) < step) {
      const path = [];
      let curr = current;
      while (curr) {
        path.unshift({ x: curr.x, y: curr.y });
        curr = curr.parent;
      }
      path.push({ x: endX, y: endY });
      return path;
    }

    const neighbors = getNeighbors(current, obstacles);
    for (const n of neighbors) {
      const nKey = `${n.x},${n.y}`;
      if (closedSet.has(nKey)) continue;

      const g = current.g + Math.hypot(n.x - current.x, n.y - current.y);
      const f = g + heuristic(n, { x: ex, y: ey });
      openSet.push({ x: n.x, y: n.y, g, f, parent: current });
    }
  }
  return [{x: endX, y: endY}];
}

const ship = new ShipSimulation();

setInterval(() => {
  ship.update(0.1);
}, 100);

app.get('/api/state', (req, res) => {
  const predicted = [];
  let px = ship.x, py = ship.y, ppsi = ship.psi, pr = ship.r, pr_dot = ship.r_dot, pdelta = ship.delta;
  for(let i=0; i<15; i++) {
    const dt = 1.0;
    const delta_dot = (ship.delta_c - pdelta) / ship.TE;
    pdelta += delta_dot * dt;
    const r_ddot = (ship.K * (pdelta + ship.T3 * delta_dot) - (ship.T1 + ship.T2) * pr_dot - pr) / (ship.T1 * ship.T2);
    pr_dot += r_ddot * dt;
    pr += pr_dot * dt;
    ppsi += pr * dt;
    px += ship.U * Math.cos(ppsi) * dt;
    py += ship.U * Math.sin(ppsi) * dt;
    predicted.push({x: px, y: py});
  }

  res.json({
    x: ship.x,
    y: ship.y,
    psi: ship.psi,
    r: ship.r,
    delta: ship.delta,
    delta_c: ship.delta_c,
    U: ship.U,
    mode: ship.mode,
    collision_warning: ship.collision_warning,
    waypoints: ship.waypoints,
    currentWaypointIndex: ship.currentWaypointIndex,
    history: ship.history,
    predicted: predicted,
    obstacles: ship.obstacles,
    params: {
      K: ship.K,
      T1: ship.T1,
      T2: ship.T2,
      T3: ship.T3,
      Kp: ship.Kp,
      Kd: ship.Kd,
      U: ship.U
    }
  });
});

app.post('/api/target', (req, res) => {
  const { x, y } = req.body;
  ship.setTarget(x, y);
  res.json({ success: true });
});

app.post('/api/mode', (req, res) => {
  const { mode } = req.body;
  if (mode === 'auto' || mode === 'manual') {
    ship.mode = mode;
  }
  res.json({ success: true });
});

app.post('/api/manual_control', (req, res) => {
  const { delta_c } = req.body;
  if (typeof delta_c === 'number') {
    ship.manual_delta_c = delta_c;
  }
  res.json({ success: true });
});

app.post('/api/params', (req, res) => {
  const p = req.body;
  if (p.K !== undefined) ship.K = p.K;
  if (p.T1 !== undefined) ship.T1 = p.T1;
  if (p.T2 !== undefined) ship.T2 = p.T2;
  if (p.T3 !== undefined) ship.T3 = p.T3;
  if (p.Kp !== undefined) ship.Kp = p.Kp;
  if (p.Kd !== undefined) ship.Kd = p.Kd;
  if (p.U !== undefined) ship.U = p.U;
  res.json({ success: true });
});

app.post('/api/reset', (req, res) => {
  ship.x = -4000;
  ship.y = -500;
  ship.psi = 0;
  ship.r = 0;
  ship.r_dot = 0;
  ship.delta = 0;
  ship.delta_c = 0;
  ship.waypoints = [];
  ship.currentWaypointIndex = 0;
  ship.history = [];
  res.json({ success: true });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(3000, '0.0.0.0', () => {
    console.log('Server running on port 3000');
  });
}

startServer();
