import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Polyline, CircleMarker, useMap, useMapEvents, Marker, Polygon } from 'react-leaflet';
import { Crosshair } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Base coordinates (San Francisco Bay area)
const BASE_LAT = 37.8267;
const BASE_LNG = -122.4230;
const METERS_PER_DEG_LAT = 111320;
const METERS_PER_DEG_LNG = 111320 * Math.cos(BASE_LAT * Math.PI / 180);

function toGeo(x: number, y: number): [number, number] {
  return [BASE_LAT + y / METERS_PER_DEG_LAT, BASE_LNG + x / METERS_PER_DEG_LNG];
}

function toLocal(lat: number, lng: number): {x: number, y: number} {
  return {
    x: (lng - BASE_LNG) * METERS_PER_DEG_LNG,
    y: (lat - BASE_LAT) * METERS_PER_DEG_LAT
  };
}

// Component to handle map clicks
function MapEvents({ onMapClick, onDragStart }: { onMapClick: (x: number, y: number) => void, onDragStart: () => void }) {
  useMapEvents({
    click(e) {
      const { lat, lng } = e.latlng;
      const local = toLocal(lat, lng);
      onMapClick(local.x, local.y);
    },
    dragstart() {
      onDragStart();
    }
  });
  return null;
}

// Component to track ship
function MapTracker({ center, isFollowing }: { center: [number, number], isFollowing: boolean }) {
  const map = useMap();
  useEffect(() => {
    if (isFollowing) {
      map.panTo(center, { animate: true, duration: 0.2 });
    }
  }, [center, map, isFollowing]);
  return null;
}

export default function Map({ state, onMapClick }: { state: any, onMapClick: (x: number, y: number) => void }) {
  const { x, y, psi, waypoints, currentWaypointIndex, history, obstacles, collision_warning, predicted } = state;
  const [isFollowing, setIsFollowing] = useState(true);

  const shipGeo = toGeo(x, y);
  const historyGeo = history.map((p: any) => toGeo(p.x, p.y));
  const waypointsGeo = waypoints.map((p: any) => toGeo(p.x, p.y));
  const predictedGeo = predicted ? predicted.map((p: any) => toGeo(p.x, p.y)) : [];
  
  // Create a continuous path from the ship to the remaining waypoints
  const activeWaypoints = waypointsGeo.length > 0 && currentWaypointIndex < waypointsGeo.length 
    ? [shipGeo, ...waypointsGeo.slice(currentWaypointIndex)] 
    : [];

  // Create custom ship icon
  const shipLength = 30;
  const shipWidth = 12;
  const shipPoints = `
    ${shipLength/2},0
    ${shipLength/4},${shipWidth/2}
    ${-shipLength/2},${shipWidth/2}
    ${-shipLength/2},${-shipWidth/2}
    ${shipLength/4},${-shipWidth/2}
  `;

  // psi is in radians. 0 is East, pi/2 is North.
  // In CSS, rotate(0deg) points right. rotate(-90deg) points up.
  const rotationDeg = -psi * 180 / Math.PI;

  const shipHtml = `
    <div style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; transform: rotate(${rotationDeg}deg);">
      <svg width="60" height="60" viewBox="-30 -30 60 60" style="overflow: visible;">
        ${collision_warning ? '<circle cx="0" cy="0" r="40" fill="rgba(239, 68, 68, 0.2)" stroke="#ef4444" stroke-width="2" class="animate-ping" />' : ''}
        <polygon points="${shipPoints}" fill="${collision_warning ? '#ef4444' : '#38bdf8'}" stroke="${collision_warning ? '#991b1b' : '#0284c7'}" stroke-width="2" />
        <line x1="0" y1="0" x2="${shipLength}" y2="0" stroke="rgba(255,255,255,0.5)" stroke-width="1" stroke-dasharray="2 2" />
      </svg>
    </div>
  `;

  const shipIcon = L.divIcon({
    html: shipHtml,
    className: '',
    iconSize: [60, 60],
    iconAnchor: [30, 30],
  });

  return (
    <div className="w-full h-full rounded-xl overflow-hidden border border-slate-800/50 relative z-0">
      <MapContainer 
        center={shipGeo} 
        zoom={16} 
        style={{ width: '100%', height: '100%', background: '#0a1128' }}
        zoomControl={false}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        />
        <TileLayer
          url="https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png"
          attribution='&copy; <a href="http://www.openseamap.org">OpenSeaMap</a>'
        />
        
        <MapEvents 
          onMapClick={(lx, ly) => { setIsFollowing(false); onMapClick(lx, ly); }} 
          onDragStart={() => setIsFollowing(false)}
        />
        <MapTracker center={shipGeo} isFollowing={isFollowing} />

        {/* Obstacles (Landmasses) */}
        {obstacles.map((obs: any, i: number) => {
          const positions = obs.map((p: any) => toGeo(p.x, p.y));
          return (
            <Polygon 
              key={i} 
              positions={positions} 
              pathOptions={{ color: '#ef4444', fillColor: '#ef4444', fillOpacity: 0.2, weight: 2 }} 
            />
          );
        })}

        {/* History */}
        {historyGeo.length > 1 && (
          <Polyline 
            positions={historyGeo} 
            pathOptions={{ color: '#f59e0b', weight: 4, opacity: 0.8 }} 
          />
        )}

        {/* Predicted Trajectory */}
        {predictedGeo.length > 1 && (
          <Polyline 
            positions={[shipGeo, ...predictedGeo]} 
            pathOptions={{ color: '#10b981', weight: 3, dashArray: '5 5', opacity: 0.9 }} 
          />
        )}

        {/* Waypoints Line */}
        {activeWaypoints.length > 1 && (
          <Polyline 
            positions={activeWaypoints} 
            pathOptions={{ color: '#0ea5e9', weight: 4, dashArray: '8 8', opacity: 0.9 }} 
          />
        )}

        {/* Waypoint Markers */}
        {waypointsGeo.map((wp: any, i: number) => {
          const isPassed = i < currentWaypointIndex;
          const isLast = i === waypointsGeo.length - 1;
          return (
            <CircleMarker 
              key={i} 
              center={wp} 
              radius={isPassed ? 3 : (isLast ? 8 : 4)}
              pathOptions={{ 
                color: isPassed ? '#64748b' : (isLast ? '#ef4444' : '#3b82f6'),
                fillColor: isPassed ? '#64748b' : (isLast ? '#ef4444' : '#3b82f6'),
                fillOpacity: isPassed ? 0.3 : 1,
                weight: 0
              }} 
            />
          );
        })}

        {/* Target Ping */}
        {waypointsGeo.length > 0 && currentWaypointIndex < waypointsGeo.length && (
          <Marker 
            position={waypointsGeo[waypointsGeo.length - 1]}
            icon={L.divIcon({
              html: '<div class="w-6 h-6 rounded-full border-2 border-red-500 animate-ping"></div>',
              className: '',
              iconSize: [24, 24],
              iconAnchor: [12, 12]
            })}
          />
        )}

        {/* Ship */}
        <Marker position={shipGeo} icon={shipIcon} zIndexOffset={1000} />

      </MapContainer>

      <button
        onClick={() => setIsFollowing(true)}
        className={`absolute bottom-8 left-8 z-[1000] p-4 rounded-2xl shadow-2xl transition-all backdrop-blur-xl border ${
          isFollowing 
            ? 'bg-blue-500/80 text-white border-blue-400/50' 
            : 'bg-black/40 text-slate-300 border-white/10 hover:bg-black/60 hover:text-white'
        }`}
        title="跟随船舶"
      >
        <Crosshair className="w-6 h-6" />
      </button>
    </div>
  );
}
