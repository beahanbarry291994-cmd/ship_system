import React from 'react';
import { Activity, Compass, Wind, Gauge, AlertTriangle } from 'lucide-react';

export default function Telemetry({ state }: { state: any }) {
  const { x, y, psi, r, delta, delta_c, U, collision_warning } = state;

  const formatAngle = (rad: number) => {
    let deg = rad * 180 / Math.PI;
    while (deg < 0) deg += 360;
    return deg.toFixed(1) + '°';
  };

  const formatRudder = (rad: number) => {
    return (rad * 180 / Math.PI).toFixed(1) + '°';
  };

  return (
    <div className={`backdrop-blur-2xl bg-black/40 border ${collision_warning ? 'border-red-500/50 shadow-[0_0_30px_rgba(239,68,68,0.2)]' : 'border-white/10'} rounded-[2rem] p-6 shadow-2xl transition-all duration-500`}>
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/20 rounded-xl border border-emerald-500/30">
            <Activity className="w-5 h-5 text-emerald-400" />
          </div>
          <h2 className="text-lg font-semibold text-white tracking-wide">实时遥测数据</h2>
        </div>
        {collision_warning && (
          <div className="flex items-center gap-1.5 text-red-400 text-sm font-bold animate-pulse bg-red-500/10 px-3 py-1.5 rounded-full border border-red-500/20">
            <AlertTriangle className="w-4 h-4" />
            碰撞预警
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white/5 p-4 rounded-2xl border border-white/10 hover:bg-white/10 transition-colors">
          <div className="text-xs text-slate-400 mb-2 flex items-center gap-1.5 font-medium"><Compass className="w-3.5 h-3.5"/> 航向角 (ψ)</div>
          <div className="text-2xl font-mono text-white font-light tracking-tight">{formatAngle(psi)}</div>
        </div>
        <div className="bg-white/5 p-4 rounded-2xl border border-white/10 hover:bg-white/10 transition-colors">
          <div className="text-xs text-slate-400 mb-2 flex items-center gap-1.5 font-medium"><Wind className="w-3.5 h-3.5"/> 偏航角速度 (r)</div>
          <div className="text-2xl font-mono text-white font-light tracking-tight">{(r * 180 / Math.PI).toFixed(2)}<span className="text-sm text-slate-500 ml-1">°/s</span></div>
        </div>
        <div className="bg-white/5 p-4 rounded-2xl border border-white/10 hover:bg-white/10 transition-colors">
          <div className="text-xs text-slate-400 mb-2 flex items-center gap-1.5 font-medium"><Gauge className="w-3.5 h-3.5"/> 实际舵角 (δ)</div>
          <div className="text-2xl font-mono text-sky-400 font-light tracking-tight">{formatRudder(delta)}</div>
          <div className="text-[11px] text-slate-400 mt-2 font-medium bg-black/20 px-2 py-1 rounded-md inline-block">指令: {formatRudder(delta_c)}</div>
        </div>
        <div className="bg-white/5 p-4 rounded-2xl border border-white/10 hover:bg-white/10 transition-colors">
          <div className="text-xs text-slate-400 mb-2 font-medium">当前坐标 (X, Y)</div>
          <div className="text-base font-mono text-slate-200 mt-1">
            {x.toFixed(0)}, {y.toFixed(0)}
          </div>
          <div className="text-xs text-emerald-400 mt-2 font-medium bg-emerald-500/10 px-2 py-1 rounded-md inline-block">航速: {U.toFixed(1)} m/s</div>
        </div>
      </div>
    </div>
  );
}
