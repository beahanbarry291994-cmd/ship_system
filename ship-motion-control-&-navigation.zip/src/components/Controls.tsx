import React, { useState, useEffect } from 'react';
import { Settings2, RefreshCw, Gamepad2, Cpu } from 'lucide-react';

export default function Controls({ 
  params, 
  mode,
  onParamChange, 
  onReset,
  onModeChange,
  onManualControl
}: { 
  params: any, 
  mode: 'auto' | 'manual',
  onParamChange: (p: any) => void, 
  onReset: () => void,
  onModeChange: (mode: 'auto' | 'manual') => void,
  onManualControl: (delta_c: number) => void
}) {
  const [manualRudder, setManualRudder] = useState(0);

  // Reset manual rudder when switching to auto
  useEffect(() => {
    if (mode === 'auto') {
      setManualRudder(0);
    }
  }, [mode]);

  const handleRudderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setManualRudder(val);
    onManualControl(val * Math.PI / 180);
  };
  const handleChange = (key: string, value: string) => {
    const val = parseFloat(value);
    if (!isNaN(val)) {
      onParamChange({ [key]: val });
    }
  };

  return (
    <div className="backdrop-blur-2xl bg-black/40 border border-white/10 rounded-[2rem] p-6 shadow-2xl flex-1 flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/20 rounded-xl border border-purple-500/30">
            <Settings2 className="w-5 h-5 text-purple-400" />
          </div>
          <h2 className="text-lg font-semibold text-white tracking-wide">控制参数与模式</h2>
        </div>
        <button
          onClick={onReset}
          className="p-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-slate-300 hover:text-white transition-all shadow-sm"
          title="重置模拟"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-8 flex-1">
        {/* Mode Switch */}
        <div className="flex bg-black/50 p-1.5 rounded-2xl border border-white/10 shadow-inner">
          <button
            onClick={() => onModeChange('auto')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl transition-all duration-300 ${
              mode === 'auto' ? 'bg-white/20 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-4 h-4" />
            自动导航
          </button>
          <button
            onClick={() => onModeChange('manual')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl transition-all duration-300 ${
              mode === 'manual' ? 'bg-white/20 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Gamepad2 className="w-4 h-4" />
            手动遥控
          </button>
        </div>

        {mode === 'manual' && (
          <div className="bg-white/5 p-5 rounded-2xl border border-white/10">
            <div className="flex justify-between text-xs text-slate-400 mb-4 font-medium">
              <span>左满舵 (-35°)</span>
              <span className="text-emerald-400 font-mono font-bold text-sm bg-emerald-500/10 px-2 py-0.5 rounded">{manualRudder.toFixed(1)}°</span>
              <span>右满舵 (35°)</span>
            </div>
            <input 
              type="range" 
              min="-35" 
              max="35" 
              step="0.5"
              value={manualRudder}
              onChange={handleRudderChange}
              className="w-full accent-emerald-500 h-2 bg-black/50 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-center mt-5">
              <button 
                onClick={() => { setManualRudder(0); onManualControl(0); }}
                className="text-sm font-medium bg-white/10 hover:bg-white/20 border border-white/10 text-white px-5 py-2 rounded-xl transition-all shadow-sm"
              >
                回正 (0°)
              </button>
            </div>
          </div>
        )}

        <div>
          <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-500/50"></span>
            Nomoto 模型 (二阶)
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <ParamInput label="增益系数 (K)" value={params.K} onChange={(v) => handleChange('K', v)} step="0.01" />
            <ParamInput label="时间常数 T1" value={params.T1} onChange={(v) => handleChange('T1', v)} step="1" />
            <ParamInput label="时间常数 T2" value={params.T2} onChange={(v) => handleChange('T2', v)} step="0.1" />
            <ParamInput label="时间常数 T3" value={params.T3} onChange={(v) => handleChange('T3', v)} step="0.1" />
          </div>
        </div>

        <div className="h-px bg-white/10 w-full"></div>

        <div>
          <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500/50"></span>
            导航与 PID 控制
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <ParamInput label="航速 (U)" value={params.U} onChange={(v) => handleChange('U', v)} step="0.5" />
            <div className="col-span-1"></div>
            <ParamInput label="比例增益 (Kp)" value={params.Kp} onChange={(v) => handleChange('Kp', v)} step="0.1" />
            <ParamInput label="微分增益 (Kd)" value={params.Kd} onChange={(v) => handleChange('Kd', v)} step="0.5" />
          </div>
        </div>
      </div>
    </div>
  );
}

function ParamInput({ label, value, onChange, step }: { label: string, value: number, onChange: (v: string) => void, step: string }) {
  return (
    <div className="bg-white/5 p-3 rounded-2xl border border-white/5 hover:border-white/20 transition-colors">
      <label className="block text-[11px] font-medium text-slate-400 mb-2">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        step={step}
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/50 transition-all font-mono"
      />
    </div>
  );
}
